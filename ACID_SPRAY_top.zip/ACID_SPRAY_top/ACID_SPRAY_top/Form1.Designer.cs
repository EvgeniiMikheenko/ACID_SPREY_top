﻿namespace ACID_SPRAY_top
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.COM = new System.IO.Ports.SerialPort(this.components);
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.ConnectMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.отключитьToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.настройкаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zedGraphControl1 = new ZedGraph.ZedGraphControl();
            this.ColorSelect = new System.Windows.Forms.ComboBox();
            this.ScalSelect = new System.Windows.Forms.ComboBox();
            this.LEDTrack = new System.Windows.Forms.TrackBar();
            this.LEDLabel = new System.Windows.Forms.Label();
            this.OE_check = new System.Windows.Forms.CheckBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.DropGraph = new ZedGraph.ZedGraphControl();
            this.Templbl = new System.Windows.Forms.Label();
            this.TempVal = new System.Windows.Forms.Label();
            this.Droplbl = new System.Windows.Forms.Label();
            this.DropVal = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LEDTrack)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // COM
            // 
            this.COM.BaudRate = 115200;
            this.COM.PortName = "COM3";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ConnectMenu});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1468, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // ConnectMenu
            // 
            this.ConnectMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.отключитьToolStripMenuItem,
            this.настройкаToolStripMenuItem});
            this.ConnectMenu.Name = "ConnectMenu";
            this.ConnectMenu.Size = new System.Drawing.Size(97, 20);
            this.ConnectMenu.Text = "Подключение";
            this.ConnectMenu.DropDownItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.ConnectMenu_DropDownItemClicked);
            this.ConnectMenu.Click += new System.EventHandler(this.ConnectMenu_Click);
            // 
            // отключитьToolStripMenuItem
            // 
            this.отключитьToolStripMenuItem.Name = "отключитьToolStripMenuItem";
            this.отключитьToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.отключитьToolStripMenuItem.Text = "Отключить";
            // 
            // настройкаToolStripMenuItem
            // 
            this.настройкаToolStripMenuItem.Name = "настройкаToolStripMenuItem";
            this.настройкаToolStripMenuItem.Size = new System.Drawing.Size(136, 22);
            this.настройкаToolStripMenuItem.Text = "Настройка";
            // 
            // zedGraphControl1
            // 
            this.zedGraphControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.zedGraphControl1.Location = new System.Drawing.Point(0, 0);
            this.zedGraphControl1.Name = "zedGraphControl1";
            this.zedGraphControl1.ScrollGrace = 0D;
            this.zedGraphControl1.ScrollMaxX = 0D;
            this.zedGraphControl1.ScrollMaxY = 0D;
            this.zedGraphControl1.ScrollMaxY2 = 0D;
            this.zedGraphControl1.ScrollMinX = 0D;
            this.zedGraphControl1.ScrollMinY = 0D;
            this.zedGraphControl1.ScrollMinY2 = 0D;
            this.zedGraphControl1.Size = new System.Drawing.Size(1135, 429);
            this.zedGraphControl1.TabIndex = 1;
            this.zedGraphControl1.UseExtendedPrintDialog = true;
            // 
            // ColorSelect
            // 
            this.ColorSelect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ColorSelect.FormattingEnabled = true;
            this.ColorSelect.Items.AddRange(new object[] {
            "White",
            "Red",
            "Green",
            "Blue",
            "ALL"});
            this.ColorSelect.Location = new System.Drawing.Point(1265, 42);
            this.ColorSelect.Name = "ColorSelect";
            this.ColorSelect.Size = new System.Drawing.Size(121, 21);
            this.ColorSelect.TabIndex = 2;
            this.ColorSelect.SelectedIndexChanged += new System.EventHandler(this.ColorSelect_SelectedIndexChanged);
            // 
            // ScalSelect
            // 
            this.ScalSelect.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.ScalSelect.FormattingEnabled = true;
            this.ScalSelect.Items.AddRange(new object[] {
            "2%",
            "20%",
            "100%",
            "OFF"});
            this.ScalSelect.Location = new System.Drawing.Point(1265, 83);
            this.ScalSelect.Name = "ScalSelect";
            this.ScalSelect.Size = new System.Drawing.Size(121, 21);
            this.ScalSelect.TabIndex = 3;
            this.ScalSelect.SelectedIndexChanged += new System.EventHandler(this.ColorSelect_SelectedIndexChanged);
            // 
            // LEDTrack
            // 
            this.LEDTrack.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.LEDTrack.Location = new System.Drawing.Point(1225, 110);
            this.LEDTrack.Maximum = 100;
            this.LEDTrack.Name = "LEDTrack";
            this.LEDTrack.Size = new System.Drawing.Size(190, 45);
            this.LEDTrack.TabIndex = 4;
            this.LEDTrack.Scroll += new System.EventHandler(this.LEDTrack_Scroll);
            // 
            // LEDLabel
            // 
            this.LEDLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.LEDLabel.AutoSize = true;
            this.LEDLabel.Location = new System.Drawing.Point(1312, 158);
            this.LEDLabel.Name = "LEDLabel";
            this.LEDLabel.Size = new System.Drawing.Size(35, 13);
            this.LEDLabel.TabIndex = 5;
            this.LEDLabel.Text = "label1";
            // 
            // OE_check
            // 
            this.OE_check.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.OE_check.AutoSize = true;
            this.OE_check.Location = new System.Drawing.Point(1167, 23);
            this.OE_check.Name = "OE_check";
            this.OE_check.Size = new System.Drawing.Size(77, 17);
            this.OE_check.TabIndex = 6;
            this.OE_check.Text = "Вкл/Выкл";
            this.OE_check.UseVisualStyleBackColor = true;
            this.OE_check.CheckedChanged += new System.EventHandler(this.ColorSelect_SelectedIndexChanged);
            // 
            // tabControl1
            // 
            this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(0, 27);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1468, 455);
            this.tabControl1.TabIndex = 7;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.ColorSelect);
            this.tabPage1.Controls.Add(this.zedGraphControl1);
            this.tabPage1.Controls.Add(this.OE_check);
            this.tabPage1.Controls.Add(this.ScalSelect);
            this.tabPage1.Controls.Add(this.LEDLabel);
            this.tabPage1.Controls.Add(this.LEDTrack);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1460, 429);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Цвет";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.DropVal);
            this.tabPage2.Controls.Add(this.Droplbl);
            this.tabPage2.Controls.Add(this.TempVal);
            this.tabPage2.Controls.Add(this.Templbl);
            this.tabPage2.Controls.Add(this.DropGraph);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1460, 429);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Капли";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // DropGraph
            // 
            this.DropGraph.Location = new System.Drawing.Point(0, 0);
            this.DropGraph.Name = "DropGraph";
            this.DropGraph.ScrollGrace = 0D;
            this.DropGraph.ScrollMaxX = 0D;
            this.DropGraph.ScrollMaxY = 0D;
            this.DropGraph.ScrollMaxY2 = 0D;
            this.DropGraph.ScrollMinX = 0D;
            this.DropGraph.ScrollMinY = 0D;
            this.DropGraph.ScrollMinY2 = 0D;
            this.DropGraph.Size = new System.Drawing.Size(1265, 429);
            this.DropGraph.TabIndex = 0;
            this.DropGraph.UseExtendedPrintDialog = true;
            // 
            // Templbl
            // 
            this.Templbl.AutoSize = true;
            this.Templbl.Location = new System.Drawing.Point(1294, 125);
            this.Templbl.Name = "Templbl";
            this.Templbl.Size = new System.Drawing.Size(61, 13);
            this.Templbl.TabIndex = 1;
            this.Templbl.Text = "Temprature";
            // 
            // TempVal
            // 
            this.TempVal.AutoSize = true;
            this.TempVal.Location = new System.Drawing.Point(1361, 125);
            this.TempVal.Name = "TempVal";
            this.TempVal.Size = new System.Drawing.Size(13, 13);
            this.TempVal.TabIndex = 2;
            this.TempVal.Text = "0";
            // 
            // Droplbl
            // 
            this.Droplbl.AutoSize = true;
            this.Droplbl.Location = new System.Drawing.Point(1294, 157);
            this.Droplbl.Name = "Droplbl";
            this.Droplbl.Size = new System.Drawing.Size(52, 13);
            this.Droplbl.TabIndex = 3;
            this.Droplbl.Text = "DropADC";
            // 
            // DropVal
            // 
            this.DropVal.AutoSize = true;
            this.DropVal.Location = new System.Drawing.Point(1361, 157);
            this.DropVal.Name = "DropVal";
            this.DropVal.Size = new System.Drawing.Size(13, 13);
            this.DropVal.TabIndex = 4;
            this.DropVal.Text = "0";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1468, 481);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.LEDTrack)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public  System.IO.Ports.SerialPort COM;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem ConnectMenu;
        private System.Windows.Forms.ToolStripMenuItem отключитьToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem настройкаToolStripMenuItem;
        private ZedGraph.ZedGraphControl zedGraphControl1;
        private System.Windows.Forms.ComboBox ColorSelect;
        private System.Windows.Forms.ComboBox ScalSelect;
        private System.Windows.Forms.TrackBar LEDTrack;
        private System.Windows.Forms.Label LEDLabel;
        private System.Windows.Forms.CheckBox OE_check;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private ZedGraph.ZedGraphControl DropGraph;
        private System.Windows.Forms.Label TempVal;
        private System.Windows.Forms.Label Templbl;
        private System.Windows.Forms.Label Droplbl;
        private System.Windows.Forms.Label DropVal;
    }
}

